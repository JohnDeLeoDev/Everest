const bcrypt = require('bcryptjs');

const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access');

const jwtSecret = db_access.config.jwtSecret;

// event.userID event.authorization

exports.handler = async (event) => {
    var pool = mysql.createPool({// credentials from db_access layer (loaded separately via console)
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database
    });

    let computer = JSON.parse(event.body.inventoryID);
    let brand = JSON.parse(event.body.brand);
    let model = JSON.parse(event.body.model);
    let description = JSON.parse(event.body.description);
    let price = JSON.parse(event.body.price);
    let memory = JSON.parse(event.body.memory);
    let storageSize = JSON.parse(event.body.storageSize);
    let processor = JSON.parse(event.body.processor);
    let processGen = JSON.parse(event.body.processGen);
    let graphics = JSON.parse(event.body.graphics);    

    var compQuery = "UPDATE Inventory SET brand = ?, model = ?, description = ?, price = ?, memory = ?, storageSize = ?, processor = ?, processGen = ?, graphics = ? WHERE inventoryID = ?";

    let result = new Promise((resolve, reject) => {
        pool.query(compQuery, [brand, model, description, price, memory, storageSize, processor, processGen, graphics, computer], function (err, data) {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });

    
    let response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin": "*"
        },
        body: "Computer updated successfully."
    };

    return response;
}


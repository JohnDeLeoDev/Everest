module.exports = {
    config: {
        "host": "everestdb.cvr2timum1d3.us-east-1.rds.amazonaws.com",
        "port": 3306,
        "user": "admin",
        "password": "XXXXXXXX"
        "database": "consignmentStore",
    },
    jwtSecret: "XXXXXXXX"
}